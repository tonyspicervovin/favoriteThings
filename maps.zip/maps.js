let metroAreaCenterCoordinates = [44.96 , -93.2]

let map = L.map('mctc-map').setView(metroAreaCenterCoordinates,9)
L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
  attribution: 'Map data &copy; <a     href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
maxZoom: 18,
id: 'mapbox.streets',
accessToken: 'pk.eyJ1IjoidG9ueS1zcGljZXItY292aW4iLCJhIjoiY2pzMjcybHIxMTV1ajQzbWczN2s4NHR4NiJ9.ui3QJi7gAQpm1X7un9XGrg'
}).addTo(map)

let mctcCoordinates = [44.9724, -93.2844]
let mctcMarker = L.marker(mctcCoordinates).addTo(map)

let stPaulCoordinates = [44.94839, -93.1099]
let stpMarker = L.marker(stPaulCoordinates).addTo(map)
